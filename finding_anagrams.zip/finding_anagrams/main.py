def find_anagram(word, anagram):
    if sorted(word) == sorted(anagram):

        return True
    else:
        return False


print(">>>>> Welcome to Anagram check App <<<<<<\n")

word = input("Please enter the first word: \n").lower()
anagram = input("Please enter the second word: \n").lower()

print(find_anagram(word, anagram))
